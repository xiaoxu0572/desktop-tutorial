@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   ==========================================
echo      点歌（AI 翻唱） - 引擎部署
echo   ==========================================
echo.
echo   接下来会下载并安装唱歌引擎，需要 20~40 分钟，
echo   会占用约 10 GB 磁盘。中途请不要关闭窗口。
echo.
pause
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy.ps1"
if errorlevel 1 goto fail
goto end
:fail
echo.
echo   部署失败。请右键 deploy.ps1 -^> 使用 PowerShell 运行，看具体报错。
pause
:end
