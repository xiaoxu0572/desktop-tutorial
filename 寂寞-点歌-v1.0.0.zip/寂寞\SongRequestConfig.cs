namespace 寂寞;

/// <summary>
/// 点歌插件配置。
/// 这里只管「插件怎么连到唱歌服务」，唱歌参数（换声步数、混音响度等）在
/// qqbot-music 项目的 config.toml 里。
/// </summary>
public record SongRequestConfig
{
    // ---------------- 服务连接 ----------------

    /// <summary>唱歌服务地址，默认 http://127.0.0.1:8766，一般不用改</summary>
    public string 服务地址 { get; set; } = "http://127.0.0.1:8766";

    /// <summary>Alife 启动时自动拉起唱歌服务，崩了自动重启，退出时一起关。建议保持开启</summary>
    public bool 自动启动服务 { get; set; } = true;

    /// <summary>引擎目录。留空 = 用户目录下的 qqbot-music（deploy.ps1 默认装到这里）。已经部署在别处才需要填</summary>
    public string 项目目录 { get; set; } = "";

    /// <summary>跑引擎的 python.exe 完整路径。留空则自动用「引擎目录\.venv\Scripts\python.exe」</summary>
    public string Python解释器 { get; set; } = "";

    // ---------------- 音色 ----------------

    /// <summary>
    /// 自定义音色参考音的文件路径。要求：10~25 秒、干净（无伴奏、无混响）的说话或清唱录音。
    /// 填了之后，Alife 启动时会把这段音频复制成 qqbot-music 的 voice/reference.wav，重启后生效。
    /// 留空则沿用 qqbot-music 里现有的参考音。
    /// 提示：参考音里的语气起伏比时长更重要——念白的合成音换出来会很"通用"，真人录音才有辨识度。
    /// </summary>
    public string 音色参考音路径 { get; set; } = "";

    // ---------------- 行为 ----------------

    /// <summary>曲库没有这首歌时最多等多久让它学（秒）。0 = 不等，直接回「还在学」</summary>
    public int 学歌最多等待秒数 { get; set; } = 240;

    /// <summary>默认唱整首。关掉则只唱副歌，30 秒左右，快很多</summary>
    public bool 默认唱整首 { get; set; } = true;

    /// <summary>唱好的 wav 放在哪。留空 = Alife 数据目录下的 SingOut</summary>
    public string 成品输出目录 { get; set; } = "";

    // ---------------- B 站登录 ----------------

    /// <summary>
    /// B 站登录 cookie。学新歌要用：没有它，B 站搜索会被风控，只会返回翻唱和片段，学不出来。
    /// 获取方法：浏览器登录 bilibili.com → F12 打开开发者工具 → Application（应用）
    /// → 左侧 Cookies → https://www.bilibili.com → 复制整段，或者只复制 SESSDATA 的值。
    /// 不填也能用，只是只能唱本地导入的音频。
    /// </summary>
    public string B站Cookie { get; set; } = "";

    /// <summary>上次更新 cookie 的日期，写给自己看的提醒（不参与逻辑）</summary>
    public string Cookie更新时间 { get; set; } = "";
}
