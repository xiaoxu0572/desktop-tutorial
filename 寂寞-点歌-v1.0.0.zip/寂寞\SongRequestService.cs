using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace 寂寞;

/// <summary>
/// 点歌：让机器人用指定音色翻唱任意歌。
///
/// 真正的活儿在 qqbot-music 里跑（独立 Python 服务，原作者：小小墨）：
///   找原唱 → 下载 → 分离人声/伴奏 → 零样本换声（音色参考音由用户提供）→ 按伴奏定响度混音
/// 本插件负责：拉起并看护那个服务、给 AI 提供调用入口、把成品落盘交给 QFile 发出去。
/// </summary>
[Module(
    "点歌（AI 翻唱）",
    """
    让机器人用指定音色翻唱任意歌。
    调用 SingSong 给歌名：曲库里有的直接唱；没有的会自己上网找原唱、下载、分离、定副歌，学会后直接开唱，不用再问第二次。
    唱好返回 wav 的本地路径，用 QFile 发给对方。

    ⚠️ 编辑本插件前请先把 Alife 窗口全屏（或最大化），否则这段简介会把设置页撑满，看不到下面的输入框。

    · 换音色：设置里填一段 10~25 秒干净录音（无伴奏无混响）的路径，重启后就用那个嗓子。留空则沿用已有的参考音。
    · 引擎来源：唱歌内核是 qqbot-music（作者：小小墨，github.com/aa1805370178-dot/qqbot-music，GPL-3.0）。
      本插件不含它的任何代码，首次使用请在插件目录双击 deploy.ps1，自动拉取并部署（含模型下载，约 3GB）。
    · B 站 cookie：浏览器登录 bilibili.com → F12 → Application → 左侧 Cookies → https://www.bilibili.com
      → 复制整段（或只复制 SESSDATA 的值）粘到「B站Cookie」。不填也能用，只是只能唱本地导入的歌。
    """,
    defaultCategory: "寂寞 & 小小墨")]
public class SongRequestService(
    XmlFunctionCaller functionService,
    ILogger<SongRequestService> logger) : ChatBehaviour, IConfigurable<SongRequestConfig>
{
    public SongRequestConfig Configuration { get; set; } = null!;

    // ---------------- 状态（给 UI 看） ----------------

    /// <summary>当前在做什么，给 UI 显示。空闲时为空串。</summary>
    public string CurrentTask { get; private set; } = "";

    /// <summary>最近一次任务的结果说明</summary>
    public string LastResult { get; private set; } = "";

    /// <summary>本插件自己拉起来的服务进程</summary>
    Process? server;
    CancellationTokenSource? watchCts;

    // ---------------- 路径与端口 ----------------

    /// <summary>默认引擎位置：用户主目录下的 qqbot-music（部署脚本默认装在这）</summary>
    public static string DefaultEngineDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "qqbot-music");

    /// <summary>这个目录里是不是真的有一套 qqbot-music</summary>
    static bool IsEngineDir(string dir) =>
        dir.Length > 0 && File.Exists(Path.Combine(dir, "qqbot_music", "__main__.py"));

    /// <summary>
    /// 实际使用的引擎目录。
    /// 设置里填了就用填的；没填则先找用户主目录下的 qqbot-music（deploy.ps1 默认装在这），
    /// 找不到再认几个常见位置——很多人是早就手动装在别处的，不该逼他再填一遍。
    /// </summary>
    public string WorkDir
    {
        get
        {
            string custom = Configuration?.项目目录?.Trim().TrimEnd('\\') ?? "";
            if (custom.Length > 0) return custom;

            string home = DefaultEngineDir;
            if (IsEngineDir(home)) return home;

            foreach (string guess in new[] { @"D:\qqbot-music", @"C:\qqbot-music", @"E:\qqbot-music" })
                if (IsEngineDir(guess)) return guess;

            return home;   // 都没有就返回默认位置，报错信息里能看出该装哪
        }
    }

    public string ResolvedPython
    {
        get
        {
            string p = Configuration?.Python解释器?.Trim() ?? "";
            if (p.Length > 0) return p;
            return Path.Combine(WorkDir, ".venv", "Scripts", "python.exe");
        }
    }

    public string ServiceBase
    {
        get
        {
            string u = Configuration?.服务地址?.Trim() ?? "";
            return string.IsNullOrEmpty(u) ? "http://127.0.0.1:8766" : u.TrimEnd('/');
        }
    }

    int ServicePort
    {
        get
        {
            try { return new Uri(ServiceBase).Port; }
            catch { return 8766; }
        }
    }

    string LibraryIndexPath => Path.Combine(WorkDir, "library", "library.json");

    public string OutputDir => string.IsNullOrWhiteSpace(Configuration?.成品输出目录)
        ? Path.Combine(Path.GetFullPath(AlifePath.StorageFolderPath), "SingOut")
        : Configuration.成品输出目录.Trim();

    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(20) };

    // ---------------- 生命周期 ----------------

    protected override Task OnAwake()
    {
        string vr = ApplyVoiceReference();
        if (vr.StartsWith("已应用"))
            logger.LogInformation("自定义音色：{Msg}", vr);

        string ck = ApplyBilibiliCookie();
        if (ck.StartsWith("已写入"))
            logger.LogInformation("B 站 cookie：{Msg}", ck);

        if (Configuration?.自动启动服务 == true)
        {
            watchCts = CancellationTokenSource.CreateLinkedTokenSource(DestroyCancellationToken);
            _ = Task.Run(() => SuperviseAsync(watchCts.Token), CancellationToken.None);
        }
        return Task.CompletedTask;
    }

    /// <summary>
    /// 把配置里指定的「音色参考音」复制成 qqbot-music 的 voice/reference.wav。
    /// 用户换一段录音就能换嗓子，不用手动去翻项目目录。
    /// </summary>
    public string ApplyVoiceReference()
    {
        try
        {
            string src = Configuration?.音色参考音路径?.Trim().Trim('"') ?? "";
            if (src.Length == 0) return "沿用现有参考音";
            if (!File.Exists(src)) return "找不到音色文件：" + src;

            string dir = Path.Combine(WorkDir, "voice");
            Directory.CreateDirectory(dir);
            string dst = Path.Combine(dir, "reference.wav");

            if (string.Equals(Path.GetFullPath(src), Path.GetFullPath(dst), StringComparison.OrdinalIgnoreCase))
                return "已经是目标文件";

            var a = new FileInfo(src);
            var b = new FileInfo(dst);
            if (b.Exists && a.Length == b.Length && b.LastWriteTime >= a.LastWriteTime)
                return "已应用（未变化）";

            File.Copy(src, dst, overwrite: true);
            return "已应用：" + Path.GetFileName(src);
        }
        catch (Exception e)
        {
            logger.LogWarning(e, "应用自定义音色失败");
            return "应用失败：" + e.Message;
        }
    }

    protected override Task OnDestroy()
    {
        try { watchCts?.Cancel(); } catch { }
        StopServer();
        return Task.CompletedTask;
    }

    /// <summary>
    /// 把设置里的 B 站 cookie 写进引擎的 config.toml（download.bilibili_sessdata）。
    /// 不写进去，「学新歌」会被 B 站风控挡住——这是「说歌名就能唱」能成立的前提。
    /// </summary>
    public string ApplyBilibiliCookie()
    {
        try
        {
            string ck = Configuration?.B站Cookie?.Trim() ?? "";
            if (ck.Length == 0) return "未填写";

            string cfg = Path.Combine(WorkDir, "config.toml");
            if (!File.Exists(cfg)) return "找不到 config.toml：" + cfg;

            string text = File.ReadAllText(cfg, Encoding.UTF8);

            // TOML 的多行字面量（三个单引号）里面不转义反斜杠，
            // 正好装得下 cookie 里那些 " 号、| 和 %；真碰上三个连续单引号才退回转义写法。
            string line = ck.Contains("'''")
                ? "bilibili_sessdata = \"" + ck.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""
                : "bilibili_sessdata = '''" + ck + "'''";

            var rx = new System.Text.RegularExpressions.Regex(@"(?m)^[ \t]*bilibili_sessdata[ \t]*=.*$");
            if (!rx.IsMatch(text))
            {
                text = text.TrimEnd() + "\n" + line + "\n";
            }
            else
            {
                if (rx.Match(text).Value.Trim() == line.Trim()) return "未变化";
                text = rx.Replace(text, _ => line);
            }

            File.WriteAllText(cfg, text, new UTF8Encoding(false));
            return "已写入 config.toml（重启唱歌服务后生效）";
        }
        catch (Exception e)
        {
            logger.LogWarning(e, "写入 B 站 cookie 失败");
            return "写入失败：" + e.Message;
        }
    }

    // ---------------- 服务进程管理 ----------------

    public bool PortInUse(int port)
    {
        try
        {
            using var c = new TcpClient();
            var t = c.ConnectAsync("127.0.0.1", port);
            return t.Wait(TimeSpan.FromMilliseconds(600)) && c.Connected;
        }
        catch { return false; }
    }

    public bool ServiceOnline => PortInUse(ServicePort);

    void StartServer()
    {
        if (PortInUse(ServicePort))
        {
            logger.LogInformation("唱歌服务已在 {Port} 端口运行，跳过启动", ServicePort);
            return;
        }
        if (!Directory.Exists(WorkDir))
        {
            logger.LogWarning("qqbot-music 目录不存在：{Dir}", WorkDir);
            return;
        }
        if (!File.Exists(ResolvedPython))
        {
            logger.LogWarning("找不到 Python：{Path}", ResolvedPython);
            return;
        }
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = ResolvedPython,
                Arguments = "-u -m qqbot_music serve",
                WorkingDirectory = WorkDir,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = false,
                RedirectStandardError = false,
            };
            server = Process.Start(psi);
            logger.LogInformation("唱歌服务已启动，PID {Pid}", server?.Id);
        }
        catch (Exception e)
        {
            logger.LogError(e, "启动唱歌服务失败");
            server = null;
        }
    }

    /// <summary>服务没起来就拉起来，并等它监听端口。给「闲置后第一次点歌」用。</summary>
    async Task<bool> EnsureServiceAsync(int waitSeconds)
    {
        if (ServiceOnline) return true;
        if (Configuration?.自动启动服务 != true) return false;

        StartServer();
        DateTime deadline = DateTime.UtcNow.AddSeconds(Math.Max(5, waitSeconds));
        while (DateTime.UtcNow < deadline)
        {
            await Task.Delay(1500);
            if (ServiceOnline) return true;
        }
        return ServiceOnline;
    }

    void StopServer()
    {
        try
        {
            if (server != null && server.HasExited == false)
            {
                server.Kill(entireProcessTree: true);
                logger.LogInformation("唱歌服务已停止");
            }
        }
        catch { }
        server = null;
    }

    async Task SuperviseAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            if (server == null || server.HasExited)
                StartServer();
            try { await Task.Delay(5000, ct); }
            catch (OperationCanceledException) { break; }
        }
        StopServer();
    }

    /// <summary>手动启停（给 UI 按钮用）</summary>
    public void RestartService()
    {
        StopServer();
        Task.Delay(800).ContinueWith(_ => StartServer());
    }

    // ---------------- HTTP ----------------

    async Task<JsonElement> GetJsonAsync(string path)
    {
        string body = await Http.GetStringAsync(ServiceBase + path);
        using JsonDocument doc = JsonDocument.Parse(body);
        return doc.RootElement.Clone();
    }

    async Task<JsonElement> PostJsonAsync(string path, object payload)
    {
        using var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
        using HttpResponseMessage resp = await Http.PostAsync(ServiceBase + path, content);
        string body = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
            throw new Exception($"{resp.StatusCode} {body}".Trim());
        using JsonDocument doc = JsonDocument.Parse(body);
        return doc.RootElement.Clone();
    }

    static string Str(JsonElement e, string name)
        => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out JsonElement v) && v.ValueKind == JsonValueKind.String
            ? (v.GetString() ?? "")
            : "";

    static string Q(string s) => Uri.EscapeDataString(s ?? "");

    // ---------------- 曲库（读本地索引给 UI 用） ----------------

    public sealed class SongEntry
    {
        public string Id = "";
        public string Title = "";
        public string Artist = "";
        public string Status = "";
        public double Duration;
        public double ChorusStart;
        public double ChorusEnd;
        public string Error = "";
        public string Source = "";
    }

    public List<SongEntry> Library
    {
        get
        {
            var list = new List<SongEntry>();
            try
            {
                if (!File.Exists(LibraryIndexPath)) return list;
                using JsonDocument doc = JsonDocument.Parse(File.ReadAllText(LibraryIndexPath, Encoding.UTF8));
                foreach (JsonProperty kv in doc.RootElement.EnumerateObject())
                {
                    JsonElement v = kv.Value;
                    var e = new SongEntry
                    {
                        Id = kv.Name,
                        Title = Str(v, "title"),
                        Artist = Str(v, "artist"),
                        Status = Str(v, "status"),
                        Error = Str(v, "error"),
                        Source = Str(v, "source"),
                    };
                    if (v.TryGetProperty("duration", out JsonElement d) && d.ValueKind == JsonValueKind.Number)
                        e.Duration = d.GetDouble();
                    if (v.TryGetProperty("chorus", out JsonElement c) && c.ValueKind == JsonValueKind.Array && c.GetArrayLength() >= 2)
                    {
                        e.ChorusStart = c[0].GetDouble();
                        e.ChorusEnd = c[1].GetDouble();
                    }
                    list.Add(e);
                }
            }
            catch (Exception e)
            {
                logger.LogWarning(e, "读曲库索引失败");
            }
            return list.OrderBy(x => x.Title).ToList();
        }
    }

    /// <summary>把本地音频导入曲库（不联网）。给 UI 的「导入音频」用。</summary>
    public string ImportAudio(string path)
    {
        try
        {
            path = (path ?? "").Trim().Trim('"');
            if (!File.Exists(path)) return "文件不存在：" + path;
            if (!ServiceOnline) return "唱歌服务没在运行，先点上面的「重启服务」。";

            string dir = Path.Combine(WorkDir, "library", "audio");
            Directory.CreateDirectory(dir);
            string name = Path.GetFileName(path);
            string target = Path.Combine(dir, name);
            if (!string.Equals(Path.GetFullPath(path), Path.GetFullPath(target), StringComparison.OrdinalIgnoreCase))
                File.Copy(path, target, overwrite: true);

            string args = $"-u -m qqbot_music add \"{target}\" \"{Path.GetFileNameWithoutExtension(name)}\" \"\"";
            var psi = new ProcessStartInfo
            {
                FileName = ResolvedPython,
                Arguments = args,
                WorkingDirectory = WorkDir,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            using Process? p = Process.Start(psi);
            p?.WaitForExit();
            return p?.ExitCode == 0 ? "已导入：" + name : "导入失败，看控制台输出";
        }
        catch (Exception e)
        {
            return "导入失败：" + e.Message;
        }
    }

    // ---------------- 给 AI 的函数 ----------------

    [XmlFunction(FunctionMode.OneShot)]
    [Description("用你自己的音色唱一首歌。title 填歌名（留空则随机唱曲库里的一首），artist 可选。曲库里没有时会自动上网学（下载原唱、分离、定副歌），最多等几分钟，学会后直接开唱——不需要你再问第二次。vocalOnly=true 只要纯人声。返回 wav 的本地路径，拿到后用 QFile 发出去。")]
    public async Task<string> SingSong(
        [Description("歌名，例如：晴天")] string title = "",
        [Description("歌手名，可留空")] string artist = "",
        [Description("只要纯人声就传 true")] bool vocalOnly = false)
    {
        try
        {
            title = (title ?? "").Trim();
            artist = (artist ?? "").Trim();

            CurrentTask = string.IsNullOrEmpty(title) ? "随机选歌" : $"查曲库：{title}";
            if (!ServiceOnline)
            {
                // 引擎闲置 10 分钟会自己退出让显存，用户第一次点歌不能就吃个闭门羹
                CurrentTask = "正在启动唱歌服务（首次要加载模型，稍等）";
                if (!await EnsureServiceAsync(90))
                {
                    CurrentTask = "";
                    return "唱歌服务起不来。请到插件设置页点「重启服务」；还是不行就跑一次 deploy.ps1，或者看引擎目录里的报错。";
                }
            }

            JsonElement r = string.IsNullOrEmpty(title)
                ? await GetJsonAsync("/random")
                : await GetJsonAsync("/find?title=" + Q(title) + (artist.Length > 0 ? "&artist=" + Q(artist) : ""));

            string status = Str(r, "status");
            string id = Str(r, "id");
            string songTitle = Str(r, "title");

            if (status is "unknown" or "failed" or "learning")
            {
                if (string.IsNullOrEmpty(title)) return "曲库是空的，也没给我歌名，唱不了。";

                if (status != "learning")
                {
                    CurrentTask = $"让服务去学：{title}";
                    await PostJsonAsync("/learn", new { title, artist });
                }

                int wait = Math.Max(0, Configuration?.学歌最多等待秒数 ?? 240);
                DateTime deadline = DateTime.UtcNow.AddSeconds(wait);
                while (wait > 0 && DateTime.UtcNow < deadline)
                {
                    await Task.Delay(10000);
                    CurrentTask = $"等它学完：{title}（已 {DateTime.UtcNow:HH:mm:ss}）";
                    JsonElement again = await GetJsonAsync(
                        "/find?title=" + Q(title) + (artist.Length > 0 ? "&artist=" + Q(artist) : ""));
                    string st2 = Str(again, "status");
                    if (st2 == "ready")
                    {
                        id = Str(again, "id");
                        songTitle = Str(again, "title");
                        break;
                    }
                    if (st2 == "failed")
                    {
                        CurrentTask = "";
                        return $"「{title}」学不会：{Str(again, "error")}。B 站可能没有对得上原唱的版本。";
                    }
                }

                if (id.Length == 0)
                {
                    CurrentTask = "";
                    return $"「{title}」还在学（下载加分离比较慢）。过一会儿再让我唱一次。";
                }
            }

            if (id.Length == 0) return "查询没返回曲目 id，唱不了。";
            if (songTitle.Length == 0) songTitle = title;

            CurrentTask = $"正在唱：{songTitle}";
            bool full = Configuration?.默认唱整首 ?? true;
            var body = JsonSerializer.Serialize(new { id, full, vocal_only = vocalOnly });
            using var content = new StringContent(body, Encoding.UTF8, "application/json");
            using HttpResponseMessage resp = await Http.PostAsync(ServiceBase + "/sing", content);
            if (!resp.IsSuccessStatusCode)
            {
                string err = await resp.Content.ReadAsStringAsync();
                CurrentTask = "";
                return "唱歌失败：" + err.Trim();
            }
            byte[] wav = await resp.Content.ReadAsByteArrayAsync();
            if (wav.Length < 1024) return "唱歌服务返回的内容太小，可能失败了。";

            Directory.CreateDirectory(OutputDir);
            string safe = songTitle;
            foreach (char c in Path.GetInvalidFileNameChars()) safe = safe.Replace(c, '_');
            if (safe.Length == 0) safe = "song";
            string file = Path.Combine(OutputDir, $"{safe}{(vocalOnly ? "_人声" : "_伴奏版")}_{DateTime.Now:MMdd_HHmmss}.wav");
            await File.WriteAllBytesAsync(file, wav);

            LastResult = $"{songTitle} → {file}";
            CurrentTask = "";
            return $"唱好了：《{songTitle}》{(vocalOnly ? "（纯人声）" : "（带伴奏）")}，文件在 {file}（{wav.Length / 1048576.0:F1} MB）。现在用 QFile 把它发给对方。";
        }
        catch (Exception e)
        {
            CurrentTask = "";
            logger.LogError(e, "唱歌失败");
            return "唱歌失败：" + e.Message + "。确认唱歌服务在运行（设置页可以重启它）。";
        }
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查看曲库里现在会唱哪些歌")]
    public string ListLibrary()
    {
        try
        {
            var lib = Library.Where(x => x.Status == "ready").ToList();
            if (lib.Count == 0) return "曲库还是空的，一首都不会。给我歌名我去学。";
            var sb = new StringBuilder($"会唱 {lib.Count} 首：");
            foreach (SongEntry s in lib.Take(40))
                sb.Append("\n- ").Append(s.Title).Append(s.Artist.Length > 0 ? "（" + s.Artist + "）" : "");
            if (lib.Count > 40) sb.Append($"\n…还有 {lib.Count - 40} 首");
            return sb.ToString();
        }
        catch (Exception e) { return "读曲库失败：" + e.Message; }
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("唱歌服务当前状态：是否在线、曲库有多少首、正在做什么")]
    public string ServiceStatus()
    {
        bool on = ServiceOnline;
        int n = Library.Count(x => x.Status == "ready");
        string task = CurrentTask.Length > 0 ? "，正在：" + CurrentTask : "";
        return (on ? "唱歌服务在线" : "唱歌服务离线") + $"，会唱 {n} 首{task}。目录：{WorkDir}";
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("换掉唱歌用的音色。给一个 10~25 秒、干净（无伴奏无混响）的说话或清唱录音的文件路径，立刻生效，不用重启。")]
    public string SetVoiceReference([Description("音频文件的完整路径")] string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath)) return "要给我一个音频文件的完整路径。";
        if (Configuration == null) return "配置还没加载好。";

        Configuration.音色参考音路径 = filePath.Trim().Trim('"');
        string r = ApplyVoiceReference();
        return r.StartsWith("已应用")
            ? $"音色已换成「{Path.GetFileName(filePath)}」，下一次唱就用这个嗓子。"
            : "换音色失败：" + r;
    }
}
