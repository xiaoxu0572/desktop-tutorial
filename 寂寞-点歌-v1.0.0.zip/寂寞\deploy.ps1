﻿# ============================================================
#  寂寞 · 小小墨 —— 引擎部署脚本
#  作用：在你的电脑上装好唱歌引擎（qqbot-music）以及它的依赖。
#  用法：右键“使用 PowerShell 运行”，或者在 PowerShell 里执行
#        powershell -ExecutionPolicy Bypass -File deploy.ps1
#
#  说明：唱歌内核 qqbot-music 由 小小墨 开发（github.com/aa1805370178-dot/qqbot-music，GPL-3.0）。
#        本脚本只负责下载和安装，不打包、不修改它的代码，版权归原作者。
# ============================================================

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Root      = if ($env:QQMUSIC_DIR) { $env:QQMUSIC_DIR } else { Join-Path $env:USERPROFILE "qqbot-music" }
$Mirror    = "https://gh-proxy.com/"
$PyVer     = "3.10"
$TorchIdx  = "https://download.pytorch.org/whl/cu128"
$PipIdx    = "https://pypi.tuna.tsinghua.edu.cn/simple"
$CKptUrl   = "https://modelscope.cn/models/giantailab/YingMusic-SVC/resolve/master/bs_roformer.ckpt"

function Say($m, $c = "White") { Write-Host $m -ForegroundColor $c }

Say "==============================================" Cyan
Say "  寂寞 & 小小墨 · 点歌  引擎部署" Cyan
Say "==============================================" Cyan
Say "安装位置：$Root"
Say ""

# ---------- 1. 目录 ----------
New-Item -ItemType Directory -Force -Path $Root | Out-Null
Set-Location $Root

# ---------- 2. 拉取 qqbot-music ----------
if (Test-Path (Join-Path $Root "qqbot_music\__main__.py")) {
    Say "[1/5] 引擎代码已存在，跳过" Green
} else {
    Say "[1/5] 下载唱歌引擎代码..." Yellow
    $zip = Join-Path $Root "qqbot-music.zip"
    Invoke-WebRequest -Uri "${Mirror}https://codeload.github.com/aa1805370178-dot/qqbot-music/zip/refs/heads/master" -OutFile $zip -TimeoutSec 600
    Expand-Archive -Path $zip -DestinationPath $Root -Force
    $inner = Get-ChildItem $Root -Directory | Where-Object { $_.Name -like "qqbot-music*" } | Select-Object -First 1
    if ($inner) {
        Get-ChildItem $inner.FullName -Force | ForEach-Object { Move-Item $_.FullName (Join-Path $Root $_.Name) -Force }
        Remove-Item $inner.FullName -Recurse -Force
    }
    Remove-Item $zip -Force
    Say "      完成" Green
}

# ---------- 3. 拉取依赖仓库（换声 / 分离） ----------
$tp = Join-Path $Root "third_party"
New-Item -ItemType Directory -Force -Path $tp | Out-Null

function Get-Repo($name, $url, $check) {
    $dir = Join-Path $tp $name
    if (Test-Path (Join-Path $dir $check)) { Say "      $name 已存在" Green; return }
    $z = Join-Path $tp "$name.zip"
    Invoke-WebRequest -Uri "${Mirror}$url" -OutFile $z -TimeoutSec 600
    Expand-Archive -Path $z -DestinationPath $tp -Force
    $inner = Get-ChildItem $tp -Directory | Where-Object { $_.Name -like "$name*" -and $_.Name -ne $name } | Select-Object -First 1
    if ($inner) {
        if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
        Move-Item $inner.FullName $dir -Force
    }
    Remove-Item $z -Force
    Say "      $name 完成" Green
}

Say "[2/5] 下载换声与分离组件（约 60MB）..." Yellow
Get-Repo "seed-vc" "https://codeload.github.com/Plachtaa/seed-vc/zip/refs/heads/main" "inference.py"
Get-Repo "YingMusic-SVC" "https://codeload.github.com/GiantAILab/YingMusic-SVC/zip/refs/heads/main" "requirements.txt"

# ---------- 4. 分离模型 ----------
$ck = Join-Path $Root "third_party\YingMusic-SVC\ckpt\bs_roformer.ckpt"
if ((Test-Path $ck) -and ((Get-Item $ck).Length -gt 100MB)) {
    Say "[3/5] 分离模型已存在，跳过" Green
} else {
    Say "[3/5] 下载分离模型 bs_roformer.ckpt（1.2GB，慢慢等）..." Yellow
    New-Item -ItemType Directory -Force -Path (Split-Path $ck) | Out-Null
    Invoke-WebRequest -Uri $CKptUrl -OutFile $ck -TimeoutSec 3600
    Say "      完成" Green
}

# ---------- 5. Python 环境 ----------
$venv = Join-Path $Root ".venv"
$py   = Join-Path $venv "Scripts\python.exe"
if (Test-Path $py) {
    Say "[4/5] Python 环境已存在，跳过" Green
} else {
    Say "[4/5] 安装 Python $PyVer 环境（约 6GB，最慢的一步）..." Yellow

    $uv = Join-Path $Root "uv.exe"
    if (-not (Test-Path $uv)) {
        Invoke-WebRequest -Uri "https://gh-proxy.com/https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" -OutFile "$Root\uv.zip" -TimeoutSec 600
        Expand-Archive -Path "$Root\uv.zip" -DestinationPath "$Root\uvtmp" -Force
        $exe = Get-ChildItem "$Root\uvtmp" -Filter "uv.exe" -Recurse | Select-Object -First 1
        Move-Item $exe.FullName $uv -Force
        Remove-Item "$Root\uv.zip","$Root\uvtmp" -Recurse -Force
    }

    & $uv venv --python $PyVer $venv
    & $uv pip install --python $py torch==2.7.1 torchaudio==2.7.1 --index-url $TorchIdx
    & $uv pip install --python $py --index-url $PipIdx numpy==1.26.4 "scipy>=1.11,<1.14" librosa==0.10.2 soundfile requests pyyaml av einops munch "transformers==4.46.3" ml_collections beartype rotary_embedding_torch hyper_connections huggingface-hub==0.36.2 tomli
    & $uv pip install --python $py --no-deps --index-url $PipIdx descript-audio-codec
    Say "      完成" Green

    # descript-audio-codec 的 audiotools 依赖在这些场景用不到，补两行让 import 通过
    $dac1 = Join-Path $venv "Lib\site-packages\dac\__init__.py"
    if (Test-Path $dac1) {
        $c = Get-Content $dac1 -Raw -Encoding UTF8
        if ($c -notmatch "# patched by SongRequest") {
            $c = ($c -replace "import audiotools", "# patched by SongRequest`n# import audiotools") -replace "^from \. import model", "# from . import model"
            $c += "`n# patched by SongRequest"
            Set-Content $dac1 $c -Encoding UTF8
        }
    }
}

# ---------- 6. 配置与参考音 ----------
$cfg = Join-Path $Root "config.toml"
if (-not (Test-Path $cfg)) {
    Copy-Item (Join-Path $Root "config.example.toml") $cfg
    Say "[5/5] 已生成 config.toml" Green
} else {
    Say "[5/5] config.toml 已存在，保留你的设置" Green
}

New-Item -ItemType Directory -Force -Path (Join-Path $Root "voice") | Out-Null
if (-not (Test-Path (Join-Path $Root "voice\reference.wav"))) {
    Say ""
    Say "！！！还差最后一步：音色参考音" Red
    Say "  放一段 10~25 秒、干净（无伴奏无混响）的说话或清唱录音到：" Yellow
    Say "  $Root\voice\reference.wav" Yellow
    Say "  然后在插件设置里把「音色参考音路径」指向这个文件。" Yellow
}

Say ""
Say "==============================================" Cyan
Say "  部署完成。重启 Alife 即可。" Green
Say "  引擎位置：$Root" Cyan
Say "==============================================" Cyan
Read-Host "按回车退出"
